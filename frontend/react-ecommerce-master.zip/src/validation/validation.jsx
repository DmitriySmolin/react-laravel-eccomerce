class validation {
     static NameRegx = /^[A-Za-z\'\s\.\:\-]+$/;
}

export default validation
